#include <iostream>
#include <mpi.h>

using namespace std;

int main(int argc, char* argv[])
{
	int errCode;

	if ((errCode = MPI_Init(&argc, &argv)) != 0)
	{
		return errCode;
	}

	cout << "hello world\n";
	

	MPI_Finalize();
	return 0;
}